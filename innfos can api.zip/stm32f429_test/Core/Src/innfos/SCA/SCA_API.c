/**
  ******************************************************************************
  * @File: SCA_API.c
  * @Author: INNFOS Software Team
  * @版本: V1.5.3
  * @日期: 2019.09.10
  * @Abstract: SCA control interface layer
  ******************************************************************************/ 
/* Update log --------------------------------------------------------------------*/
//V1.1.0 2019.08.05 All API call interfaces are changed to ID, which is consistent with the PC SDK, adding all parameter read and write APIs
//V1.5.0 2019.08.16 Change the data receiving method (interrupt receiving), add non-blocking communication function, adapt to slow data return
//					Happening. Add the API to get the last shutdown state to optimize the startup process.
//V1.5.1 2019.09.10 add polling function
//V1.5.3 2019.11.15 Optimize the switch machine process

/* Includes ----------------------------------------------------------------------*/
#include "bsp.h"
#include "SCA_API.h"
#include <string.h>

/* Variable defines --------------------------------------------------------------*/

/* Each SCA needs a handle to save the corresponding information, which is defined according to the actual number of use SCA_NUM_USE */
SCA_Handler_t SCA_Handler_List[SCA_NUM_USE];

/* Funcation declaration ---------------------------------------------------------*/
extern void warnBitAnaly(SCA_Handler_t* pSCA);

/* Funcation defines -------------------------------------------------------------*/

/****************************�������*******************************/

/**
  * @Function Find the existing SCA on the CAN bus and print the ID found
  * @Parameter canPort: The bus that needs to be polled
  * @回回 None
  * @Note Each actuator has its own ID, if you don’t know it for the first time
  * Corresponding ID, use this function to find
  */
void lookupActuators(CAN_Handler_t* canPort)
{
	uint16_t ID;
	uint8_t Found = 0;
	SCA_Handler_t temp;
	
	/* Save the original content of the list item */
	temp = SCA_Handler_List[0];
	
	/* Use a list item to query */
	SCA_Handler_List[0].Can = canPort;
	
	for(ID = 1; ID <= 0xFF; ID++)
	{
		/* Load new ID */
		SCA_Handler_List[0].ID = ID;
		
		/* Receive the heartbeat of the ID, the ID exists */
		if(isOnline(ID,Block) == SCA_NoError)
		{
			/* Record the number found and print the ID found */
			Found++;
			SCA_Debug("Found ID %d in canPort %d\r\n",ID,canPort->CanPort);
		}
	}
	/* Revert changed content */
	SCA_Handler_List[0] = temp;
	
	/* Output prompt message */
	SCA_Debug("canPort %d polling done ! Found %d Actuators altogether!\r\n\r\n",canPort->CanPort,Found);
}

/**
  * @Function Initialize the controller for ID and CAN port information
  * @Parameter id: the ID of the initial actuator
  * pCan: CAN port address used
  * @回回 None
  * @Note The number of definitions should not exceed SCA_NUM_USE
  */
void setupActuators(uint8_t id, CAN_Handler_t* pCan)
{
	static uint32_t i = 0;
	
	/* The number of definitions exceeds the number used */
	if(i >= SCA_NUM_USE)	return;
	
	/* Handle binding information */
	SCA_Handler_List[i].ID = id;
	SCA_Handler_List[i].Can = pCan;
	
	/* List item increase */
	i++;
}

/**
  * @Function reset the controller, used for SCA crash restart due to error
  * @Parameter id: 0 means all reset, if it is not 0, reset the controller with the specified ID
  * @回回 None
  * @Note If there is a dead SCA with red or blue light, please change
  * Power on the SCA again, return to the yellow light state and execute this letter
  * Count and execute the boot function to complete the crash restart
  */
void resetController(uint8_t id)
{
	uint8_t i,id_temp;
	CAN_Handler_t* pCan_temp = NULL;
	
	if(id == 0)
	{
		/* Clear all information handles */
		for(i = 0; i < SCA_NUM_USE; i++)
		{
			/* Reserved ID and CAN port address */
			id_temp = SCA_Handler_List[i].ID;
			pCan_temp = SCA_Handler_List[i].Can;
			
			/* Clear the structure */
			memset(&SCA_Handler_List[i], 0, sizeof(SCA_Handler_List[i]));
			
			/* Restore ID and CAN port address */
			SCA_Handler_List[i].ID = id_temp;
			SCA_Handler_List[i].Can = pCan_temp;
		}
	}else
	{
		/* Get the information handle of the ID */
		SCA_Handler_t* pSCA = getInstance(id);
		if(pSCA == NULL)	return;
		
		/* Reserved CAN port address */
		pCan_temp = pSCA->Can;
		
		/* Clear the structure */
		memset(pSCA, 0, sizeof(SCA_Handler_List[0]));
		
		/* Restore ID and CAN port address */
		pSCA->ID = id;
		pSCA->Can = pCan_temp;
	}
}

/**
  * @Function Get the SCA information handle of the specified ID
  * @Parameter id: The ID of the actuator to obtain information
  * @回回 NULL: The information handle of the ID is not found
  * Other: the information handle found
  */
SCA_Handler_t* getInstance(uint8_t id)
{
	uint8_t i;
	
    for(i = 0; i < SCA_NUM_USE; i++)
        if(SCA_Handler_List[i].ID == id)
            return &SCA_Handler_List[i];
	
    return NULL;
}

/**
  * @Function Check the heartbeat (online) status of the actuator
  * @Parameter id: the id of the actuator to be checked
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: The actuator is online
  * SCA_OverTime: The actuator is offline
  * For other communication errors, see SCA_Error error list
  */
uint8_t isOnline(uint8_t id, uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = getInstance(id);

	if(pSCA == NULL)	return SCA_UnknownID;

	/* Clear the online status first */
	pSCA->Online_State = Actr_Disable;
	
	/* Call the read command to communicate with SCA, and put the result into the corresponding SCA handle */
	Error = SCA_Read(pSCA, R1_Heartbeat);
	if(Error)	return Error;

	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);	
		return Error;
	}
	
	/* Blocking communication */
	while((pSCA->Online_State != Actr_Enable) && (waitime++ < CanOvertime));
	if(waitime >= CanOvertime)	return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Check the enable state of the actuator
  * @Parameter id: the id of the actuator to be checked
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 Actr_Enable: The actuator has been enabled
  * Actr_Disable: The actuator is not enabled
  *
  */
uint8_t isEnable(uint8_t id, uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL)	return SCA_UnknownID;
	
	/* Clear the read flag first */
	pSCA->paraCache.R_Power_State = Actr_Disable;
	
	/* Call the read command to communicate with SCA, and put the result into the corresponding SCA handle */
	Error = SCA_Read(pSCA, R1_PowerState);
	if(Error)	return Error;

	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);	
		return Error;
	}
	
	/* Blocking communication */
	while((pSCA->paraCache.R_Power_State != Actr_Enable) && (waitime++ < CanOvertime));
	if(waitime >= CanOvertime)	return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Check the parameter update status of the actuator
  * @Parameter id: the id of the actuator to be checked
  * @回回 Actr_Enable: parameter update
  * Actr_Disable: No parameter update
  */
uint8_t isUpdate(uint8_t id)
{
	uint8_t State;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL)	return SCA_UnknownID;
	
	/* Save the update status and reset */
	State = pSCA->Update_State;
	pSCA->Update_State = Actr_Disable;
	
	return State;
}

/**
  * @Function Enable all actuators, blocking type
  * @Parameter None
  * @回回 None
  */
void enableAllActuators()
{
	uint8_t i;

	for(i = 0; i < SCA_NUM_USE; i++)
		enableActuator(SCA_Handler_List[i].ID);
}

/**
  * @Function Disable all actuators, blocking type
  * @Parameter None
  * @回回 None
  */
void disableAllActuators()
{
	uint8_t i;

	for(i = 0; i < SCA_NUM_USE; i++)
		disableActuator(SCA_Handler_List[i].ID);
}

/**
  * @Function Actuator enable, blocking
  * @Parameter id: actuator ID to be enabled
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t enableActuator(uint8_t id)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL)	return SCA_UnknownID;
	
	/* Query the current enable state once */
	Error = isEnable(id, Block);
	if(Error)	return Error;

	/* If you are currently in the target state, directly return success */
	if(pSCA->Power_State == Actr_Enable)	goto PowerOn;
	
	/* The target parameter is written to the cache to be updated */
	pSCA->paraCache.Power_State = Actr_Enable;
	
	/* Execute boot command */
	Error = SCA_Write_1(pSCA, W1_PowerState, Actr_Enable);
	if(Error)	return Error;

	/* Wait for the successful boot, update the handle information */
	while((pSCA->Power_State != Actr_Enable) && (waitime++ < CanPowertime));
	if(waitime >= CanPowertime)	return SCA_OperationFailed;			
	
	PowerOn:
	/* Update online status */
	pSCA->Online_State = Actr_Enable;
	
	/* Read out the serial number of the device and use it to change the ID */
	getActuatorSerialNumber(id,Block);

	/* Read the abnormal state of the last shutdown */
	getActuatorLastState(id,Block);
	if(pSCA->Last_State == 0)		// Prompt that the last shutdown state is abnormal
		SCA_Debug("ID:%d Last_State Error\r\n",pSCA->ID);
	
	/* Read the full-scale current value of the actuator, which is used when reading and writing current loop parameters,
	The value of SCA is different for different models, and it can also be manually updated to the handle information
	The parameter value must be obtained. */
	getCurrentRange(id,Block);
	if(pSCA->Current_Max == 0)	// The current full scale value is not obtained, and the current value cannot be writtenֵ
		SCA_Debug("ID:%d Current_Max Error\r\n",pSCA->ID);
	
	/* Update all parameters to the handle once, and use non-blocking to shorten the boot time */
	regainAttrbute(id,Unblock);

	return Error;
}

/**
  * @Function Actuator is disabled, blocked
  * @Parameter id: the ID of the actuator to be disabled
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t disableActuator(uint8_t id)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL)	return SCA_UnknownID;
	
	/* Query the current enable state once */
	Error = isEnable(id, Block);
	if(Error)	return Error;

	/* If you are currently in the target state, directly return success */
	if(pSCA->Power_State == Actr_Disable)	return SCA_NoError;
	
	/* The target parameter is written to the cache to be updated */
	pSCA->paraCache.Power_State = Actr_Disable;
	
	/* Execute shutdown command */
	Error = SCA_Write_1(pSCA, W1_PowerState, Actr_Disable);
	if(Error)	return Error;
	
	/* Wait for the shutdown to succeed */
	while((pSCA->Power_State != Actr_Disable) && (waitime++ < CanPowertime));
	if(waitime >= CanPowertime)	return SCA_OperationFailed;	
	
	return Error;
}

/**
  * @Function Actuator switch operation mode
  * @Parameter id: the id of the actuator to be operated
  * mode: operation mode, see SCA_Protocol.h for details
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t activateActuatorMode(uint8_t id, uint8_t ActuatorMode, uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* If you are currently in the target state, directly return success */
	if(pSCA->Mode == ActuatorMode) return SCA_NoError;
	
	/* The target parameter is written to the cache to be updated */
	pSCA->paraCache.Mode = ActuatorMode;

	/* Execute mode switching command */
	Error = SCA_Write_1(pSCA, W1_Mode, ActuatorMode);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->Mode != ActuatorMode) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function The actuator reads the current operating mode
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getActuatorMode(uint8_t id, uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL)	return SCA_UnknownID;
	
	/* First clear the read waiting flag */
	pSCA->paraCache.R_Mode = Actr_Disable;
	
	/* Encapsulate the read function, and save the read value directly to the handle */
	Error = SCA_Read(pSCA, R1_Mode);
	if(Error)	return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)	
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Mode != Actr_Enable) && (waitime++ < CanOvertime));
	if(waitime >= CanOvertime)	return SCA_OperationFailed;	
	
	return Error;
}

/**
  * @Function The actuator reads the alarm information and updates it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getErrorCode(uint8_t id, uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL)	return SCA_UnknownID;
	
	/* First clear the read waiting flag */
	pSCA->paraCache.R_Error_Code = Actr_Disable;
	
	/* Execute read error information command */
	Error = SCA_Read(pSCA, R2_Error);
	if(Error)	return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)	
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Error_Code != Actr_Enable) && (waitime++ < CanOvertime));
	if(waitime >= CanOvertime)	return SCA_OperationFailed;	
	
	return Error;
}

/**
  * @Function Actuator clears alarm information
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t clearError(uint8_t id, uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL)	return SCA_UnknownID;

	/* If there is no error, there is no need to make an error */
	if(pSCA->SCA_Warn.Error_Code == 0)	return SCA_NoError;

	/* Execute wrong command */
	Error = SCA_Write_4(pSCA, W4_ClearError);
	
	/* Non-blocking */
	if(isBlock == Unblock)	
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}

	/* Wait for the execution result */
	while((pSCA->SCA_Warn.Error_Code != 0) && (waitime++ < CanOvertime));
	if(waitime >= CanOvertime)	return SCA_OperationFailed;	
	
	return Error;
}

/**
  * @Function The actuator gets all current parameters
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 None
  */
void regainAttrbute(uint8_t id,uint8_t isBlock)
{
	getErrorCode(id,isBlock);
	requestCVPValue(id,isBlock);
	getActuatorMode(id,isBlock);
	getPositionKp(id,isBlock);
	getPositionKi(id,isBlock);
	getPositionUmax(id,isBlock);
	getPositionUmin(id,isBlock);
	getPositionOffset(id,isBlock);
	getMaximumPosition(id,isBlock);
	getMinimumPosition(id,isBlock);
	isPositionLimitEnable(id,isBlock);
	isPositionFilterEnable(id,isBlock);
	getPositionCutoffFrequency(id,isBlock);
	getProfilePositionAcceleration(id,isBlock);
	getProfilePositionDeceleration(id,isBlock);
	getProfilePositionMaxVelocity(id,isBlock);
	getVelocityKp(id,isBlock);
	getVelocityKi(id,isBlock);
	getVelocityUmax(id,isBlock);
	getVelocityUmin(id,isBlock);
	isVelocityFilterEnable(id,isBlock);
	getVelocityCutoffFrequency(id,isBlock);
	getVelocityLimit(id,isBlock);
	getProfileVelocityAcceleration(id,isBlock);
	getProfileVelocityDeceleration(id,isBlock);
	getProfileVelocityMaxVelocity(id,isBlock);
	getCurrentKp(id,isBlock);
    getCurrentKi(id,isBlock);
	isCurrentFilterEnable(id,isBlock);
	getCurrentCutoffFrequency(id,isBlock);
	getCurrentLimit(id,isBlock);
	getVoltage(id,isBlock);
	getLockEnergy(id,isBlock);
	getMotorTemperature(id,isBlock);
	getInverterTemperature(id,isBlock);
	getMotorProtectedTemperature(id,isBlock);
	getMotorRecoveryTemperature(id,isBlock);
	getInverterProtectedTemperature(id,isBlock);
	getInverterRecoveryTemperature(id,isBlock);
}
/**
  * @Function The actuator saves all current parameters
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t saveAllParams(uint8_t id, uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL)	return SCA_UnknownID;
	
	/* Clear the storage status bit */
	pSCA->Save_State = Actr_Disable;
	
	Error = SCA_Write_4(pSCA, W4_Save);
	if(Error)	return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)	
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution to succeed */
	while((pSCA->Save_State != Actr_Enable) && (waitime++ < CanOvertime));
	if(waitime >= CanPowertime)	return SCA_OperationFailed;	
	
	return Error;
}


/****************************Location related ********************* ************/

/**
  * @Function The actuator sets the current position value
  * @Parameter id: the id of the actuator to be operated
  * pos: target position value, actual value, range -127.0R ~ +127.0R
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setPosition(uint8_t id, float pos)
{
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL)	return SCA_UnknownID;
	
	return SCA_Write_3(pSCA, W3_Position, pos);
}

/**
  * @Function The actuator sets the current position value, fast
  * @Parameter pSCA: the actuator handle pointer or address to be operated
  * pos: target position value, actual value, range -127.0R ~ +127.0R
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setPositionFast(SCA_Handler_t* pSCA, float pos)
{
	return SCA_Write_3(pSCA, W3_Position, pos);
}

/**
  * @Function The actuator reads the current position value and updates it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getPosition(uint8_t id, uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL)	return SCA_UnknownID;
	
	/* Clear the status bit */
	pSCA->paraCache.R_Position_Real = Actr_Disable;
	
	Error = SCA_Read(pSCA, R3_Position);
	if(Error)	return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)	
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution to succeed */
	while((pSCA->paraCache.R_Position_Real != Actr_Enable) && (waitime++ < CanOvertime));
	if(waitime >= CanPowertime)	return SCA_OperationFailed;	
	
	return Error;
}

/**
  * @Function The actuator reads the current position value and updates it to the handle, fast
  * @Parameter pSCA: the address or pointer of the actuator handle to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getPositionFast(SCA_Handler_t* pSCA, uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	
	/* Clear the status bit */
	pSCA->paraCache.R_Position_Real = Actr_Disable;
	
	Error = SCA_Read(pSCA, R3_Position);
	if(Error)	return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)	
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution to succeed */
	while((pSCA->paraCache.R_Position_Real != Actr_Enable) && (waitime++ < CanOvertime));
	if(waitime >= CanPowertime)	return SCA_OperationFailed;	
	
	return Error;
}

/**
  * @Function Set the Kp value of the actuator position loop
  * @Parameter id: the id of the actuator to be operated
  * Kp: Kp value of target position loop, actual value
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setPositionKp(uint8_t id,float Kp, uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL)	return SCA_UnknownID;
	
	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.Position_Filter_P = Kp;
	
	Error = SCA_Write_3(pSCA, W3_PositionFilterP, Kp);
	if(Error)	return Error;

	/* Non-blocking */
	if(isBlock == Unblock)	
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->Position_Filter_P != Kp) && (waitime++ < CanOvertime));
	if(waitime >= CanOvertime)	return SCA_OperationFailed;	

	return Error;
}

/**
  * @Function Get the Kp value of the actuator position loop and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getPositionKp(uint8_t id, uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* Clear the status bit */
	pSCA->paraCache.R_Position_Filter_P = Actr_Disable;
	
	Error = SCA_Read(pSCA, R3_PositionFilterP);
	if(Error) return Error;

	/* Non-blocking */
	if(isBlock == Unblock)	
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Position_Filter_P != Actr_Enable) && (waitime++ < CanOvertime));
	if(waitime >= CanOvertime)	return SCA_OperationFailed;	

	return Error;
}

/**
  * @Function Set the Ki value of the actuator position loop
  * @Parameter id: the id of the actuator to be operated
  * Ki: target position loop Ki value, actual value
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setPositionKi(uint8_t id,float Ki, uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.Position_Filter_I = Ki;
	
	Error = SCA_Write_3(pSCA, W3_PositionFilterI, Ki);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)	
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}

	/* Wait for the execution result */
	while((pSCA->Position_Filter_I != Ki) && (waitime++ < CanOvertime));
	if(waitime >= CanOvertime)	return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Get the Ki value of the actuator position loop and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getPositionKi(uint8_t id, uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* Clear the status bit */
	pSCA->paraCache.R_Position_Filter_I = Actr_Disable;
	
	Error = SCA_Read(pSCA, R3_PositionFilterI);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)	
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}

	/* Wait for the execution result */
	while((pSCA->paraCache.R_Position_Filter_I != Actr_Enable) && (waitime++ < CanOvertime));
	if(waitime >= CanOvertime)	return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Set the upper limit of actuator position loop output
  * @Parameter id: the id of the actuator to be operated
  * max: target position loop output upper limit value, actual value
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setPositionUmax(uint8_t id,float max,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.Position_Filter_Limit_H = max;
	
	Error = SCA_Write_3(pSCA, W3_PositionFilterLimitH, max);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)	
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}

	/* Wait for the execution result */
	while((pSCA->Position_Filter_Limit_H != max) && (waitime++ < CanOvertime));
	if(waitime >= CanOvertime)	return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Get the upper limit value of the actuator position loop output and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getPositionUmax(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* Clear the status bit */
	pSCA->paraCache.R_Position_Filter_Limit_H = Actr_Disable;
	
	Error = SCA_Read(pSCA, R3_PositionFilterLimitH);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}

	/* Wait for the execution result */
	while((pSCA->paraCache.R_Position_Filter_Limit_H != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Set the lower limit of the actuator position loop output
  * @Parameter id: the id of the actuator to be operated
  * min: target position loop output lower limit value, actual value
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setPositionUmin(uint8_t id,float min,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.Position_Filter_Limit_L = min;
	
	Error = SCA_Write_3(pSCA, W3_PositionFilterLimitL, min);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->Position_Filter_Limit_L != min) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Get the lower limit value of the actuator position loop output and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getPositionUmin(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* Clear the status bit */
	pSCA->paraCache.R_Position_Filter_Limit_L = Actr_Disable;
	
	Error = SCA_Read(pSCA, R3_PositionFilterLimitL);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}

	/* Wait for the execution result */
	while((pSCA->paraCache.R_Position_Filter_Limit_L != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Set the actuator position offset value
  * @Parameter id: the id of the actuator to be operated
  * offset: target position offset value, actual value
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setPositionOffset(uint8_t id, float offset,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.Position_Offset = offset;
	
	Error = SCA_Write_3(pSCA, W3_PositionOffset, offset);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->Position_Offset != offset) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Get the actuator position offset value and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getPositionOffset(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* Clear the status bit */
	pSCA->paraCache.R_Position_Offset = Actr_Disable;
	
	Error = SCA_Read(pSCA, R3_PositionOffset);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Position_Offset != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Set the maximum value of the actuator position
  * @Parameter id: the id of the actuator to be operated
  * maxPos: Maximum target position, actual value
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setMaximumPosition(uint8_t id,float maxPos,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.Position_Limit_H = maxPos;
	
	Error = SCA_Write_3(pSCA, W3_PositionLimitH, maxPos);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->Position_Limit_H != maxPos) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Get the maximum value of the actuator position and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getMaximumPosition(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* Clear the status bit */
	pSCA->paraCache.R_Position_Limit_H = Actr_Disable;
	
	Error = SCA_Read(pSCA, R3_PositionLimitH);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Position_Limit_H != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Set the minimum value of the actuator position
  * @Parameter id: the id of the actuator to be operated
  * minPos: minimum target position, actual value
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setMinimumPosition(uint8_t id,float minPos,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.Position_Limit_L = minPos;
	
	Error = SCA_Write_3(pSCA, W3_PositionLimitL, minPos);
	if(Error) return Error;

	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->Position_Limit_L != minPos) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Get the minimum value of the actuator position and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getMinimumPosition(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* Clear the status bit */
	pSCA->paraCache.R_Position_Limit_L = Actr_Disable;
	
	Error = SCA_Read(pSCA, R3_PositionLimitL);
	if(Error) return Error;

	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Position_Limit_L != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Enable or disable actuator position limit
  * @Parameter id: the id of the actuator to be operated
  * enable: enable status, Actr_Enable is enabled, Actr_Disable is disabled
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t enablePositionLimit(uint8_t id, uint8_t enable,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.Position_Limit_State = enable;
	
	Error = SCA_Write_1(pSCA, W1_PositionLimitState, enable);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->Position_Limit_State != enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Get the enable status of the actuator position limit and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t isPositionLimitEnable(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* Clear the status bit */
	pSCA->paraCache.R_Position_Limit_State = Actr_Disable;
	
	Error = SCA_Read(pSCA, R1_PositionLimitState);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Position_Limit_State != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Set the zero position of the actuator and recalculate the left and right limits
  * @Parameter id: the id of the actuator to be operated
  * homingPos: zero position, actual value, unit R
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setHomingPosition(uint8_t id,float homingPos,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.Homing_Value = homingPos;
	
	Error = SCA_Write_3(pSCA, W3_HomingValue, homingPos);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->Homing_Value != homingPos) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Enable actuator position loop filter
  * @Parameter id: the id of the actuator to be operated
  * enable: enable status, Actr_Enable is enabled, Actr_Disable is disabled
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t enablePositionFilter(uint8_t id,uint8_t enable,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.Position_Filter_State = enable;
	
	Error = SCA_Write_1(pSCA, W1_PositionFilterState, enable);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->Position_Filter_State != enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Get the enable status of the actuator position loop filter and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t isPositionFilterEnable(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* Clear the status bit */
	pSCA->paraCache.R_Position_Filter_State = Actr_Disable;
	
	Error = SCA_Read(pSCA, R1_PositionFilterState);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Position_Filter_State != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Set the bandwidth of the actuator position loop filter
  * @Parameter id: the id of the actuator to be operated
  * frequency: filter bandwidth, actual value, unit hz
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setPositionCutoffFrequency(uint8_t id, float frequency,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.Position_Filter_Value = frequency;
	
	Error = SCA_Write_2(pSCA, W2_PositionFilterValue, frequency);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->Position_Filter_Value != frequency) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Get the bandwidth of the actuator position loop filter and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getPositionCutoffFrequency(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* Clear the status bit */
	pSCA->paraCache.R_Position_Filter_Value = Actr_Disable;
	
	Error = SCA_Read(pSCA, R2_PositionFilterValue);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Position_Filter_Value != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Clear homing information, including left and right limit and 0 bit, to be determined
  * @Parameter id: actuator id
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t clearHomingInfo(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* Clear the status bit */
	pSCA->paraCache.W_ClearHome = Actr_Disable;
	
	Error = SCA_Write_4(pSCA, W4_ClearHome);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.W_ClearHome != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Set the maximum acceleration of the actuator trapezoidal position loop
  * @Parameter id: the id of the actuator to be operated
  * acceleration: maximum acceleration, actual value, unit RPM/S^2
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setProfilePositionAcceleration(uint8_t id, float acceleration,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.PP_Max_Acceleration = acceleration;
	
	/* The transmission value of the trapezoidal acceleration is IQ20 times the real value, and the third type of read-write interface is based on
	For transmission in IQ24 format, multiple IQ4 processing is required. In addition, change the value of
	The unit is RPM, and the value needs to be scaled by 60 into RPM units.
	Final scaling value = 2^4 * 60 = 960
	*/
	acceleration /= Profile_Scal;
	
	Error = SCA_Write_3(pSCA, W3_PPMaxAcceleration, acceleration);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->PP_Max_Acceleration != acceleration) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Get the maximum acceleration of the trapezoidal position loop of the actuator and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getProfilePositionAcceleration(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* Clear the status bit */
	pSCA->paraCache.R_PP_Max_Acceleration = Actr_Disable;
	
	Error = SCA_Read(pSCA, R3_PPMaxAcceleration);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_PP_Max_Acceleration != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Set the maximum deceleration of the actuator trapezoidal position loop
  * @Parameter id: the id of the actuator to be operated
  * deceleration: maximum deceleration, actual value, unit RPM/S^2
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setProfilePositionDeceleration(uint8_t id, float deceleration,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.PP_Max_Deceleration = deceleration;
	
	deceleration /= Profile_Scal;
	
	Error = SCA_Write_3(pSCA, W3_PPMaxDeceleration, deceleration);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->PP_Max_Deceleration != deceleration) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Get the maximum deceleration of the actuator trapezoidal position loop and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getProfilePositionDeceleration(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* Clear the status bit */
	pSCA->paraCache.R_PP_Max_Deceleration = Actr_Disable;
	
	Error = SCA_Read(pSCA, R3_PPMaxDeceleration);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_PP_Max_Deceleration != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Set the maximum speed of the actuator trapezoidal position loop
  * @Parameter id: the id of the actuator to be operated
  * maxVelocity: maximum velocity, actual value, unit RPM
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setProfilePositionMaxVelocity(uint8_t id, float maxVelocity,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.PP_Max_Velocity = maxVelocity;
	
	maxVelocity /= Profile_Scal;
	
	Error = SCA_Write_3(pSCA, W3_PPMaxVelocity, maxVelocity);
	if(Error) return Error;

	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->PP_Max_Velocity != maxVelocity) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Get the maximum speed of the actuator trapezoidal position loop and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getProfilePositionMaxVelocity(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* Clear the status bit */
	pSCA->paraCache.R_PP_Max_Velocity = Actr_Disable;
	
	Error = SCA_Read(pSCA, R3_PPMaxVelocity);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_PP_Max_Velocity != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}


/****************************Speed ​​related ***************** ************/

/**
  * @Function Set the current speed value of the actuator
  * @Parameter id: the id of the actuator to be operated
  * vel: target speed, actual value, unit RPM
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setVelocity(uint8_t id,float vel)
{
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	return SCA_Write_3(pSCA, W3_Velocity, vel);
}

/**
  * @Function Set the current speed value of the actuator, fast
  * @Parameter pSCA: the actuator handle pointer or address to be operated
  * vel: target speed, actual value, unit RPM
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setVelocityFast(SCA_Handler_t* pSCA,float vel)
{
	return SCA_Write_3(pSCA, W3_Velocity, vel);
}

/**
  * @Function Get the current speed of the actuator and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getVelocity(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* Clear the status bit */
	pSCA->paraCache.R_Velocity_Real = Actr_Disable;
	
	Error = SCA_Read(pSCA, R3_Velocity);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Velocity_Real != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Get the current speed of the actuator, update it to the handle, fast
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getVelocityFast(SCA_Handler_t* pSCA,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	
	/* Clear the status bit */
	pSCA->paraCache.R_Velocity_Real = Actr_Disable;
	
	Error = SCA_Read(pSCA, R3_Velocity);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Velocity_Real != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Get the actuator speed loop ratio and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getVelocityKp(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* Clear the status bit */
	pSCA->paraCache.R_Velocity_Filter_P = Actr_Disable;
	
	Error = SCA_Read(pSCA, R3_VelocityFilterP);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Velocity_Filter_P != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Set the actuator speed loop ratio
  * @Parameter id: the id of the actuator to be operated
  * Kp: Speed ​​loop ratio, actual value
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setVelocityKp(uint8_t id,float Kp,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.Velocity_Filter_P = Kp;
	
	Error = SCA_Write_3(pSCA, W3_VelocityFilterP, Kp);
	if(Error) return Error;

	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->Velocity_Filter_P != Kp) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Obtain the actuator speed loop integral and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getVelocityKi(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* Clear the status bit */
	pSCA->paraCache.R_Velocity_Filter_I = Actr_Disable;
	
	Error = SCA_Read(pSCA, R3_VelocityFilterI);
	if(Error) return Error;

	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Velocity_Filter_I != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Set the actuator speed loop integral
  * @Parameter id: the id of the actuator to be operated
  * Ki: Speed ​​loop integral, actual value
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setVelocityKi(uint8_t id, float Ki,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.Velocity_Filter_I = Ki;
	
	Error = SCA_Write_3(pSCA, W3_VelocityFilterI, Ki);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->Velocity_Filter_I != Ki) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Get the maximum output limit of the actuator speed loop and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getVelocityUmax(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* Clear the status bit */
	pSCA->paraCache.R_Velocity_Filter_Limit_H = Actr_Disable;
	
	Error = SCA_Read(pSCA, R3_VelocityFilterLimitH);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Velocity_Filter_Limit_H != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Set the maximum output limit of the actuator speed loop
  * @Parameter id: the id of the actuator to be operated
  * max: Maximum output limit, actual value
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setVelocityUmax(uint8_t id, float max,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.Velocity_Filter_Limit_H = max;
	
	Error = SCA_Write_3(pSCA, W3_VelocityFilterLimitH, max);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->Velocity_Filter_Limit_H != max) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Get the minimum output limit of the actuator speed loop and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getVelocityUmin(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* Clear the status bit */
	pSCA->paraCache.R_Velocity_Filter_Limit_L = Actr_Disable;
	
	Error = SCA_Read(pSCA, R3_VelocityFilterLimitL);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Velocity_Filter_Limit_L != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Set the minimum output limit of the actuator speed loop
  * @Parameter id: the id of the actuator to be operated
  * min: minimum output limit, actual value
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setVelocityUmin(uint8_t id, float min,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.Velocity_Filter_Limit_L = min;
	
	Error = SCA_Write_3(pSCA, W3_VelocityFilterLimitL, min);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->Velocity_Filter_Limit_L != min) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Get the speed range of the actuator speed loop
  * @Parameter id: the id of the actuator to be operated
  * @回回 Speed ​​loop speed range, actual value
  */
float getVelocityRange(uint8_t id)
{
	return Velocity_Max;
}

/**
  * @Function Enable actuator speed loop filter
  * @Parameter id: the id of the actuator to be operated
  * enable: enable status, Actr_Enable is enabled, Actr_Disable is disabled
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t enableVelocityFilter(uint8_t id,uint8_t enable,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.Velocity_Filter_State = enable;
	
	Error = SCA_Write_1(pSCA, W1_VelocityFilterState, enable);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->Velocity_Filter_State != enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Get the enable state of the actuator speed loop filter and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t isVelocityFilterEnable(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* Clear the status bit */
	pSCA->paraCache.R_Velocity_Filter_State = Actr_Disable;
	
	Error = SCA_Read(pSCA, R1_VelocityFilterState);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Velocity_Filter_State != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Get the bandwidth of the actuator speed loop filter and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getVelocityCutoffFrequency(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* Clear the status bit */
	pSCA->paraCache.R_Velocity_Filter_Value = Actr_Disable;
	
	Error = SCA_Read(pSCA, R2_VelocityFilterValue);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Velocity_Filter_Value != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Set the bandwidth of the actuator speed loop filter
  * @Parameter id: the id of the actuator to be operated
  * frequency: filter bandwidth, actual value, unit hz
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setVelocityCutoffFrequency(uint8_t id, float frequency,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.Velocity_Filter_Value = frequency;
	
	Error = SCA_Write_2(pSCA, W2_VelocityFilterValue, frequency);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->Velocity_Filter_Value != frequency) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Set the input limit of the actuator speed loop
  * @Parameter id: the id of the actuator to be operated
  * limit: input limit
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setVelocityLimit(uint8_t id,float limit,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.Velocity_Limit = limit;
	
	Error = SCA_Write_3(pSCA, W3_VelocityLimit, limit);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->Velocity_Limit != limit) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Get the input limit of the actuator speed loop and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getVelocityLimit(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* Clear the status bit */
	pSCA->paraCache.R_Velocity_Limit = Actr_Disable;
	
	Error = SCA_Read(pSCA, R3_VelocityLimit);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Velocity_Limit != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Set the acceleration of the actuator trapezoidal speed loop
  * @Parameter id: the id of the actuator to be operated
  * acceleration: acceleration, actual value
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setProfileVelocityAcceleration(uint8_t id,float acceleration,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	To
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.PV_Max_Acceleration = acceleration;
	
	acceleration /= Profile_Scal;
	
	Error = SCA_Write_3(pSCA, W3_PVMaxAcceleration, acceleration);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->PV_Max_Acceleration != acceleration) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Get the acceleration of the actuator trapezoidal speed loop and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getProfileVelocityAcceleration(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* Clear the status bit */
	pSCA->paraCache.R_PV_Max_Acceleration = Actr_Disable;
	
	Error = SCA_Read(pSCA, R3_PVMaxAcceleration);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_PV_Max_Acceleration != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Set the actuator trapezoidal speed loop deceleration
  * @Parameter id: the id of the actuator to be operated
  * deceleration: deceleration, actual value
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setProfileVelocityDeceleration(uint8_t id,float deceleration,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.PV_Max_Deceleration = deceleration;
	
	deceleration /= Profile_Scal;
	
	Error = SCA_Write_3(pSCA, W3_PVMaxDeceleration, deceleration);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->PV_Max_Deceleration != deceleration) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Get the deceleration of the actuator trapezoidal speed loop and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getProfileVelocityDeceleration(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* Clear the status bit */
	pSCA->paraCache.R_PV_Max_Deceleration = Actr_Disable;
	
	Error = SCA_Read(pSCA, R3_PVMaxDeceleration);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_PV_Max_Deceleration != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Set the maximum speed of the actuator trapezoidal speed loop
  * @Parameter id: the id of the actuator to be operated
  * maxVelocity: maximum speed, actual value, unit RPM
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setProfileVelocityMaxVelocity(uint8_t id, float maxVelocity,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.PV_Max_Velocity = maxVelocity;
	
	maxVelocity /= Profile_Scal;
	
	Error = SCA_Write_3(pSCA, W3_PVMaxVelocity, maxVelocity);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->PV_Max_Velocity != maxVelocity) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Get the maximum speed of the actuator trapezoidal speed loop and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getProfileVelocityMaxVelocity(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	/* Clear the status bit */
	pSCA->paraCache.R_PV_Max_Velocity = Actr_Disable;
	
	Error = SCA_Read(pSCA, R3_PVMaxVelocity);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_PV_Max_Velocity != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/****************************Current related ***************** ************/

/**
  * @Function Set the current value of the actuator
  * @Parameter id: the id of the actuator to be operated
  * current: current current value, actual value, unit A
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setCurrent(uint8_t id,float current)
{
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;

	return SCA_Write_3(pSCA, W3_Current, current);
}

/**
  * @Function Set the current value of the actuator, fast
  * @Parameter pSCA: the actuator handle pointer or address to be operated
  * current: current current value, actual value, unit A
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setCurrentFast(SCA_Handler_t* pSCA,float current)
{
	return SCA_Write_3(pSCA, W3_Current, current);
}

/**
  * @Function Get the current value of the actuator and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getCurrent(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;

	/* Clear the status bit */
	pSCA->paraCache.R_Current_Real = Actr_Disable;
	
	Error = SCA_Read(pSCA, R3_Current);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Current_Real != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Get the current current value of the actuator, update it to the handle, fast
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getCurrentFast(SCA_Handler_t* pSCA,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;

	/* Clear the status bit */
	pSCA->paraCache.R_Current_Real = Actr_Disable;
	
	Error = SCA_Read(pSCA, R3_Current);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Current_Real != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Get the current loop proportional value of the actuator and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getCurrentKp(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;

	/* Clear the status bit */
	pSCA->paraCache.R_Current_Filter_P = Actr_Disable;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;
	
	Error = SCA_Read(pSCA, R3_CurrentFilterP);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Current_Filter_P != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Get the current loop integral of the actuator and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getCurrentKi(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;

	/* Clear the status bit */
	pSCA->paraCache.R_Current_Filter_I = Actr_Disable;
	
	Error = SCA_Read(pSCA, R3_CurrentFilterI);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Current_Filter_I != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Get the actuator current range and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getCurrentRange(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;

	/* Clear the status bit */
	pSCA->paraCache.R_Current_Max = Actr_Disable;
	
	Error = SCA_Read(pSCA, R2_Current_Max);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Current_Max != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Enable actuator current loop filter
  * @Parameter id: the id of the actuator to be operated
  * enable: enable status, Actr_Enable is enabled, Actr_Disable is disabled
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t enableCurrentFilter(uint8_t id,uint8_t enable,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;

	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.Current_Filter_State = enable;
	
	Error = SCA_Write_1(pSCA, W1_CurrentFilterState, enable);
	if(Error) return Error;

	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->Current_Filter_State != enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Get the enable state of the current loop filter of the actuator and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t isCurrentFilterEnable(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;

	/* Clear the status bit */
	pSCA->paraCache.R_Current_Filter_State = Actr_Disable;
	
	Error = SCA_Read(pSCA, R1_CurrentFilterState);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Current_Filter_State != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Get the bandwidth of the actuator current loop filter and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getCurrentCutoffFrequency(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;

	/* Clear the status bit */
	pSCA->paraCache.R_Current_Filter_Value = Actr_Disable;
	
	Error = SCA_Read(pSCA, R2_CurrentFilterValue);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Current_Filter_Value != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Set the bandwidth of the actuator current loop filter
  * @Parameter id: the id of the actuator to be operated
  * frequency: target cut-off frequency, unit hz
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setCurrentCutoffFrequency(uint8_t id, float frequency,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;

	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.Current_Filter_Value = frequency;
	
	Error = SCA_Write_2(pSCA, W2_CurrentFilterValue, frequency);
	if(Error) return Error;

	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->Current_Filter_Value != frequency) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Set the input limit of the actuator current loop
  * @Parameter id: the id of the actuator to be operated
  * limit: input limit
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setCurrentLimit(uint8_t id,float limit,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;

	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.Current_Limit = limit;
	
	Error = SCA_Write_3(pSCA, W3_CurrentLimit, limit);
	if(Error) return Error;

	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->Current_Limit != limit) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Get the current loop input limit of the actuator and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getCurrentLimit(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;

	/* Clear the status bit */
	pSCA->paraCache.R_Current_Limit = Actr_Disable;
	
	Error = SCA_Read(pSCA, R3_CurrentLimit);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Current_Limit != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/****************************Other parameters******************* ************/

/**
  * @Function Get the actuator voltage and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getVoltage(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;

	/* Clear the status bit */
	pSCA->paraCache.R_Voltage = Actr_Disable;
	
	Error = SCA_Read(pSCA, R2_Voltage);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Voltage != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Obtain the locked-rotor energy of the actuator and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getLockEnergy(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;

	/* Clear the status bit */
	pSCA->paraCache.R_Blocked_Energy = Actr_Disable;
	
	Error = SCA_Read(pSCA, R3_BlockEngy);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
	/* Delay processing after non-blocking transmission to prevent bus overload */
	SCA_Delay(SendInterval);
	return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Blocked_Energy != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Set the energy value of the actuator locked-rotor
  * @Parameter id: the id of the actuator to be operated
  * energy: locked rotor energy value, actual value, unit J
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setLockEnergy(uint8_t id,float energy,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;

	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.Blocked_Energy = energy;
	
	Error = SCA_Write_3(pSCA, W3_BlockEngy, energy);
	if(Error) return Error;

	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->Blocked_Energy != energy) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Get the temperature value of the actuator motor and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getMotorTemperature(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;

	/* Clear the status bit */
	pSCA->paraCache.R_Motor_Temp = Actr_Disable;
	
	Error = SCA_Read(pSCA, R2_MotorTemp);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Motor_Temp != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Get the temperature value of the actuator inverter and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getInverterTemperature(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;

	/* Clear the status bit */
	pSCA->paraCache.R_Inverter_Temp = Actr_Disable;
	
	Error = SCA_Read(pSCA, R2_InverterTemp);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Inverter_Temp != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Get the protection temperature value of the actuator motor and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getMotorProtectedTemperature(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;

	/* Clear the status bit */
	pSCA->paraCache.R_Inverter_Protect_Temp = Actr_Disable;
	
	Error = SCA_Read(pSCA, R2_MotorProtectTemp);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Inverter_Protect_Temp != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Set the protection temperature value of the actuator motor
  * @Parameter id: the id of the actuator to be operated
  * temp: motor protection temperature value, actual value, unit Celsius
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setMotorProtectedTemperature(uint8_t id,float temp,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;

	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.Motor_Protect_Temp = temp;
	
	Error = SCA_Write_2(pSCA, W2_MotorProtectTemp, temp);
	if(Error) return Error;

	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->Motor_Protect_Temp != temp) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Get the recovery temperature value of the actuator motor and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getMotorRecoveryTemperature(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;

	/* Clear the status bit */
	pSCA->paraCache.R_Motor_Recover_Temp = Actr_Disable;
	
	Error = SCA_Read(pSCA, R2_MotorRecoverTemp);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Motor_Recover_Temp != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Set the recovery temperature of the actuator motor
  * @Parameter id: the id of the actuator to be operated
  * temp: motor recovery temperature value, actual value, unit Celsius
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setMotorRecoveryTemperature(uint8_t id,float temp,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;

	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.Motor_Recover_Temp = temp;
	
	Error = SCA_Write_2(pSCA, W2_MotorRecoverTemp, temp);
	if(Error) return Error;

	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->Motor_Recover_Temp != temp) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Get the protection temperature value of the actuator inverter and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getInverterProtectedTemperature(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;

	/* Clear the status bit */
	pSCA->paraCache.R_Inverter_Protect_Temp = Actr_Disable;
	
	Error = SCA_Read(pSCA, R2_InverterProtectTemp);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Inverter_Protect_Temp != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Set the protection temperature value of the actuator inverter
  * @Parameter id: the id of the actuator to be operated
  * temp: inverter protection temperature value, actual value, in degrees Celsius
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setInverterProtectedTemperature(uint8_t id,float temp,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;

	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.Inverter_Protect_Temp = temp;
	
	Error = SCA_Write_2(pSCA, W2_InverterProtectTemp, temp);
	if(Error) return Error;

	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->Inverter_Protect_Temp != temp) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Get the recovery temperature value of the actuator inverter and update it to the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getInverterRecoveryTemperature(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;

	/* Clear the status bit */
	pSCA->paraCache.R_Inverter_Recover_Temp = Actr_Disable;
	
	Error = SCA_Read(pSCA, R2_InverterRecoverTemp);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Inverter_Recover_Temp != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Set the recovery temperature of the actuator inverter
  * @Parameter id: the id of the actuator to be operated
  * temp: inverter recovery temperature value, actual value, unit Celsius
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setInverterRecoveryTemperature(uint8_t id,float temp,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;

	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.Inverter_Recover_Temp = temp;
	
	Error = SCA_Write_2(pSCA, W2_InverterRecoverTemp, temp);
	if(Error) return Error;

	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->Inverter_Recover_Temp != temp) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;

	return Error;
}

/**
  * @Function Set the id of the actuator
  * @Parameter newID: new id
  * currentID: current id
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t setActuatorID(uint8_t currentID, uint8_t newID,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;

	/* Check if the target ID already exists */
	pSCA = getInstance(newID);
	if(pSCA != NULL) return SCA_OperationFailed;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(currentID);
	if(pSCA == NULL) return SCA_UnknownID;

	/* The target parameter is written to the cache, waiting for update */
	pSCA->paraCache.ID = newID;
	
	Error = SCA_Write_5(pSCA, W5_ChangeID, newID);
	if(Error) return Error;

	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->ID != newID) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Get the serial number of the actuator and save it in the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getActuatorSerialNumber(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL)	return SCA_UnknownID;

	/* Clear the status bit */
	pSCA->paraCache.R_Serial_Num = Actr_Disable;
	
	Error = SCA_Read(pSCA, R5_ShakeHands);
	if(Error)	return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Serial_Num != Actr_Enable) && (waitime++ < CanOvertime));
	if(waitime >= CanOvertime)	return SCA_OperationFailed;
	
	return Error;

}

/**
  * @Function Get the last shutdown state of the actuator and save it in the handle
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t getActuatorLastState(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;

	/* Clear the status bit */
	pSCA->paraCache.R_Last_State = Actr_Disable;
	
	Error = SCA_Read(pSCA, R1_LastState);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_Last_State != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Get the current speed position value, update it to the handle, high efficiency
  * @Parameter id: the id of the actuator to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t requestCVPValue(uint8_t id,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;
	SCA_Handler_t* pSCA = NULL;
	
	/* Get the information handle of the ID */
	pSCA = getInstance(id);
	if(pSCA == NULL) return SCA_UnknownID;

	/* Clear the status bit */
	pSCA->paraCache.R_CVP = Actr_Disable;
	
	Error = SCA_Read(pSCA, R4_CVP);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_CVP != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}

/**
  * @Function Get the current speed position value, update it to the handle, high efficiency and fast
  * @Parameter pSCA: the actuator handle pointer or address to be operated
  * isBlock: Block is blocking, Unblock is non-blocking
  * @回回 SCA_NoError: Operation is successful
  * For other communication errors, see SCA_Error error list
  */
uint8_t requestCVPValueFast(SCA_Handler_t* pSCA,uint8_t isBlock)
{
	uint8_t Error;
	uint32_t waitime = 0;

	/* Clear the status bit */
	pSCA->paraCache.R_CVP = Actr_Disable;
	
	Error = SCA_Read(pSCA, R4_CVP);
	if(Error) return Error;
	
	/* Non-blocking */
	if(isBlock == Unblock)
	{
		/* Delay processing after non-blocking transmission to prevent bus overload */
		SCA_Delay(SendInterval);
		return Error;
	}
	
	/* Wait for the execution result */
	while((pSCA->paraCache.R_CVP != Actr_Enable) && (waitime++ <CanOvertime));
	if(waitime >= CanOvertime) return SCA_OperationFailed;
	
	return Error;
}
