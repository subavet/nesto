/**
  ************************************************** ****************************
  * @File: SCA_APP.h
  * @Author: INNFOS Software Team
  * @版本: V1.5.1
  * @日期: 2019.09.10
  * @Abstract: SCA test program
  ************************************************** ****************************/
  
#ifndef __SCA_APP_H
#define __SCA_APP_H
#include "sys.h"

void SCA_Init(void); //Controller initialization
void SCA_Homing(void); //The actuator returns to zero
void SCA_Exp1(void); //Forward and reverse Demo
void SCA_Exp2(void); //High and low speed Demo
void SCA_Lookup(void); //Find the existing ID
  
  
#endif
