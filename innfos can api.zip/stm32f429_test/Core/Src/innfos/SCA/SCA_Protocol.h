/**
  ************************************************** ****************************
  * @File: SCA_Protocol.h
  * @Author: INNFOS Software Team
  * @版本: V1.5.2
  * @日期: 2019.08.20
  * @Abstract: INNFOS CAN communication protocol layer
  ************************************************** ****************************/

#ifndef __SCA_PROTOCOL_H
#define __SCA_PROTOCOL_H

#include "sys.h"

/*! ! ! Do not modify the following macro definition information parameters! ! ! */

//INNFOS CAN communication protocol command
//The first type of read instruction
#define R1_Heartbeat			0x00
#define R1_Mode					0x55
#define R1_LastState			0xB0
#define R1_CurrentFilterState	0X71
#define R1_VelocityFilterState	0x75
#define R1_PositionFilterState	0x79
#define R1_PositionLimitState	0x8B
#define R1_PowerState			0x2B

//The second type of read instruction
#define R2_Voltage				0x45
#define R2_Current_Max			0x53
#define R2_CurrentFilterValue	0x73
#define R2_VelocityFilterValue	0x77
#define R2_PositionFilterValue	0x7B
#define R2_MotorTemp			0x5F
#define R2_InverterTemp			0x60
#define R2_InverterProtectTemp	0x62
#define R2_InverterRecoverTemp	0x64
#define R2_MotorProtectTemp		0x6C
#define R2_MotorRecoverTemp		0x6E
#define R2_Error				0xFF

//The third type of read instruction
#define R3_Current				0x04
#define R3_Velocity				0x05
#define R3_Position				0x06
#define R3_CurrentFilterP		0x15
#define R3_CurrentFilterI		0x16
#define R3_VelocityFilterP		0x17
#define R3_VelocityFilterI		0x18
#define R3_PositionFilterP		0x19
#define R3_PositionFilterI		0x1A
#define R3_PositionFilterD		0X1B
#define R3_PPMaxVelocity		0x1C
#define R3_PPMaxAcceleration	0x1D
#define R3_PPMaxDeceleration	0x1E
#define R3_PVMaxVelocity		0x22
#define R3_PVMaxAcceleration	0x23
#define R3_PVMaxDeceleration	0x24
#define R3_CurrentFilterLimitL	0x34
#define R3_CurrentFilterLimitH	0x35
#define R3_VelocityFilterLimitL	0x36
#define R3_VelocityFilterLimitH	0x37
#define R3_PositionFilterLimitL	0x38
#define R3_PositionFilterLimitH	0x39
#define R3_CurrentLimit			0x59
#define R3_VelocityLimit		0x5B
#define R3_Inertia				0x7D
#define R3_PositionLimitH		0x85
#define R3_PositionLimitL		0x86
#define R3_PositionOffset		0x8A
#define R3_HomingCurrentLimitL	0x92
#define R3_HomingCurrentLimitH	0x93
#define R3_BlockEngy			0x7F

//The fourth type of read instruction
#define R4_CVP					0x94

//The fifth type of read instruction
#define R5_ShakeHands			0x02

//The first type of write command
#define W1_Mode					0x07
#define W1_CurrentFilterState	0X70
#define W1_VelocityFilterState	0x74
#define W1_PositionFilterState	0x78
#define W1_PositionLimitState	0x8C
#define W1_PowerState			0x2A

//The second type of write command
#define W2_CurrentFilterValue	0x72
#define W2_VelocityFilterValue	0x76
#define W2_PositionFilterValue	0x7A
#define W2_InverterProtectTemp	0x61
#define W2_InverterRecoverTemp	0x63
#define W2_MotorProtectTemp		0x6B
#define W2_MotorRecoverTemp		0x6D

//The third type of write command
#define W3_Current				0x08
#define W3_Velocity				0x09
#define W3_Position				0x0A
#define W3_CurrentFilterP		0x0E
#define W3_CurrentFilterI		0x0F
#define W3_VelocityFilterP		0x10
#define W3_VelocityFilterI		0x11
#define W3_PositionFilterP		0x12
#define W3_PositionFilterI		0x13
#define W3_PositionFilterD		0X14
#define W3_PPMaxVelocity		0x1F
#define W3_PPMaxAcceleration	0x20
#define W3_PPMaxDeceleration	0x21
#define W3_PVMaxVelocity		0x25
#define W3_PVMaxAcceleration	0x26
#define W3_PVMaxDeceleration	0x27
#define W3_CurrentFilterLimitL	0x2E
#define W3_CurrentFilterLimitH	0x2F
#define W3_VelocityFilterLimitL	0x30
#define W3_VelocityFilterLimitH	0x31
#define W3_PositionFilterLimitL	0x32
#define W3_PositionFilterLimitH	0x33
#define W3_CurrentLimit			0x58
#define W3_VelocityLimit		0x5A
#define W3_PositionLimitH		0x83
#define W3_PositionLimitL		0x84
#define W3_HomingValue			0x87
#define W3_PositionOffset		0x89
#define W3_HomingCurrentLimitL	0x90
#define W3_HomingCurrentLimitH	0x91
#define W3_BlockEngy			0x7E

//The fourth type of write command
#define W4_ClearError			0xFE
#define W4_ClearHome			0x88
#define W4_Save					0x0D

//The fifth type of write command
#define W5_ChangeID				0x3D

//Variable scaling value definition
#define Velocity_Max 6000.0f //Maximum speed, fixed at 6000RPM (only for conversion)
#define BlkEngy_Scal 75.225f //Scaling value of locked rotor energy
#define Profile_Scal 960.0f //Scaling value of trapezoidal parameter
#define IQ8 256.0f //2^8
#define IQ10 1024.0f //2^10
#define IQ24 16777216.0f //2^24
#define IQ30 1073741824.0f //2^30

/* ID is the CAN sending frame ID, msg is the data to be sent (address)
   len is the length of the sent data, return 0 for success, return other failures */
typedef uint8_t (*Send_t)(uint8_t ID, uint8_t* msg, uint8_t len);

typedef struct //CAN port handle
{
	//SCA status information
	uint8_t CanPort; //The CAN port number used
	uint8_t Retry; //Number of retransmissions when the transmission fails
	Send_t Send; //Send function, see Send_t for format

}CAN_Handler_t;

typedef struct //SCA alarm information
{
	uint16_t Error_Code; //error code
	
	/* Specific alarm information, 0: normal, 1: error */
    uint8_t WARN_OVER_VOLT; //Overvoltage abnormal
    uint8_t WARN_UNDER_VOLT; //Undervoltage abnormal
    uint8_t WARN_LOCK_ROTOR; //Blocking abnormal
    uint8_t WARN_OVER_TEMP; //Overheat abnormal
    uint8_t WARN_RW_PARA; //Read and write parameters are abnormal
    uint8_t WARN_MUL_CIRCLE; //Multi-turn count abnormal
    uint8_t WARN_TEMP_SENSOR_INV; //The inverter temperature sensor is abnormal
    uint8_t WARN_CAN_BUS; //CAN communication abnormal
    uint8_t WARN_TEMP_SENSOR_MTR; //Motor temperature sensor is abnormal
    uint8_t WARN_OVER_STEP; //The position mode step is greater than 1
    uint8_t WARN_DRV_PROTEC; //DRV protection
    uint8_t WARN_DVICE; //The device is abnormal

}SCA_Warn_t;

/*
SCA variable cache, used to save the target parameter when writing the parameter, and then write it to the handle after success
The read flag is used when blocking, and the variable content can be tailored or added according to project needs
 */
typedef struct 
{
	/* basic information */
	uint8_t ID; //SCA ID number
	To
	/* The first type of data variable */
	uint8_t Mode; //Current operating mode
	uint8_t Current_Filter_State; //Current loop filter state
	uint8_t Velocity_Filter_State; //Velocity loop filter state
	uint8_t Position_Filter_State; //Speed ​​loop filter state
	uint8_t Position_Limit_State; //Position limit state
	uint8_t Power_State; //Switch machine state
	/* Read the flag */
	uint8_t R_Mode; //Read data return flag bit 1 for data return
	uint8_t R_Last_State;
	uint8_t R_Current_Filter_State;
	uint8_t R_Velocity_Filter_State;
	uint8_t R_Position_Filter_State;
	uint8_t R_Position_Limit_State;
	uint8_t R_Power_State;
	To
	/* The second type of data variable */
	float Current_Filter_Value; //Current loop filter bandwidth
	float Velocity_Filter_Value; //Speed ​​loop filter bandwidth
	float Position_Filter_Value; //Position loop filter bandwidth
	float Inverter_Protect_Temp; //Inverter protection temperature
	float Inverter_Recover_Temp; //Inverter recovery temperature
	float Motor_Protect_Temp; //Motor protection temperature
	float Motor_Recover_Temp; //Motor recovery temperature
	/* Read the flag */
	uint8_t R_Current_Filter_Value;	
	uint8_t R_Velocity_Filter_Value;
	uint8_t R_Position_Filter_Value;
	uint8_t R_Inverter_Protect_Temp;
	uint8_t R_Inverter_Recover_Temp;
	uint8_t R_Motor_Protect_Temp;	
	uint8_t R_Motor_Recover_Temp;	
	uint8_t R_Voltage;
	uint8_t R_Current_Max;
	uint8_t R_Motor_Temp;
	uint8_t R_Inverter_Temp;
	uint8_t R_Error_Code;
	
	float Current_Real; //Current current (unit: A)
	float Velocity_Real; //Current velocity (unit: RPM)
	float Position_Real; //Current position, real value (unit: R)
	float Current_Filter_P; //P value of current loop
	float Current_Filter_I; //I value of current loop
	float Velocity_Filter_P; //P value of velocity loop
	float Velocity_Filter_I; //I value of velocity loop
	float Position_Filter_P; //P value of position loop
	float Position_Filter_I; //I value of position loop
	//float Position_Filter_D; //D value of position loop
	float PP_Max_Velocity; //Maximum velocity of position trapezoid
	float PP_Max_Acceleration; //Maximum acceleration of position trapezoid
	float PP_Max_Deceleration; //Maximum value of position trapezoidal deceleration
	float PV_Max_Velocity; //Maximum velocity of velocity trapezoid
	float PV_Max_Acceleration; //Maximum acceleration of velocity trapezoid
	float PV_Max_Deceleration; //Maximum speed trapezoidal deceleration
	//float Current_Filter_Limit_L; //lower limit of current loop output
	//float Current_Filter_Limit_H; //current loop output upper limit
	float Velocity_Filter_Limit_L; //Lower limit of velocity loop output
	float Velocity_Filter_Limit_H; //Speed ​​loop output upper limit
	float Position_Filter_Limit_L; //Lower limit of position loop output
	float Position_Filter_Limit_H; //Position loop output upper limit
	float Position_Limit_H; //The upper limit of the position of the actuator
	float Position_Limit_L; //The lower limit of the position of the actuator
	float Current_Limit; //Current input limit
	float Velocity_Limit; //Speed ​​input limit
	float Homing_Value; //Homing value of actuator
	float Position_Offset; //position offset of actuator
	float Homing_Current_Limit_L; //Auto zero current lower limit
	float Homing_Current_Limit_H; //Auto zero current upper limit
	float Blocked_Energy; //Blocked rotor lock energy
	/* Read the flag */
	uint8_t R_Current_Real;
	uint8_t R_Velocity_Real;
	uint8_t R_Position_Real;
	uint8_t R_Current_Filter_P;
	uint8_t R_Current_Filter_I;
	uint8_t R_Velocity_Filter_P;
	uint8_t R_Velocity_Filter_I;
	uint8_t R_Position_Filter_P;
	uint8_t R_Position_Filter_I;
	//uint8_t R_Position_Filter_D;
	uint8_t R_PP_Max_Velocity;
	uint8_t R_PP_Max_Acceleration;
	uint8_t R_PP_Max_Deceleration;
	uint8_t R_PV_Max_Velocity;
	uint8_t R_PV_Max_Acceleration;
	uint8_t R_PV_Max_Deceleration;
	//uint8_t R_Current_Filter_Limit_L;
	//uint8_t R_Current_Filter_Limit_H;
	uint8_t R_Velocity_Filter_Limit_L;
	uint8_t R_Velocity_Filter_Limit_H;
	uint8_t R_Position_Filter_Limit_L;
	uint8_t R_Position_Filter_Limit_H;
	uint8_t R_Position_Limit_H;
	uint8_t R_Position_Limit_L;
	uint8_t R_Current_Limit;
	uint8_t R_Velocity_Limit;
	uint8_t R_Homing_Value;
	uint8_t R_Position_Offset;
	uint8_t R_Homing_Current_Limit_L;
	uint8_t R_Homing_Current_Limit_H;
	uint8_t R_Blocked_Energy;
	uint8_t R_CVP;
	uint8_t R_Serial_Num;
	uint8_t W_ClearHome;
	
}Para_Cache_t;

/*
SCA information handle, please do not change the value randomly,
Variable content can be tailored or added according to project needs
 */
typedef struct 
{
	/* Protocol data variable area */
	uint8_t ID; //SCA ID number
	uint8_t Serial_Num[4]; //Serial number
	uint8_t Save_State; //Parameter save state, 1 means saved
	uint8_t Online_State; //Current online state, 1 means online
	uint8_t Update_State; //Is there a parameter refresh, 1 means there is a parameter refresh
	CAN_Handler_t* Can; //The CAN port used
	Para_Cache_t paraCache; //Parameter cache
	To
	/* User data variable area */
	To
	/* The first type of data variable */
	uint8_t Mode; //Current operating mode
	uint8_t Last_State; //The abnormal state of the last shutdown, 1 means normal
	uint8_t Current_Filter_State; //Current loop filter state
	uint8_t Velocity_Filter_State; //Velocity loop filter state
	uint8_t Position_Filter_State; //Speed ​​loop filter state
	uint8_t Position_Limit_State; //Position limit state
	uint8_t Power_State; //Switch machine state
	To
	/* The second type of data variable */
	float Voltage; //Current voltage (unit: V)
	float Current_Max; //Maximum current range
	float Current_Filter_Value; //Current loop filter bandwidth
	float Velocity_Filter_Value; //Speed ​​loop filter bandwidth
	float Position_Filter_Value; //Position loop filter bandwidth
	float Motor_Temp; //Motor temperature
	float Inverter_Temp; //Inverter temperature
	float Inverter_Protect_Temp; //Inverter protection temperature
	float Inverter_Recover_Temp; //Inverter recovery temperature
	float Motor_Protect_Temp; //Motor protection temperature
	float Motor_Recover_Temp; //Motor recovery temperature
	SCA_Warn_t SCA_Warn; //Motor warning information
	
	/* The third type of data variable */
	float Current_Real; //Current current (unit: A)
	float Velocity_Real; //Current velocity (unit: RPM)
	float Position_Real; //Current position, real value (unit: R)
	float Current_Filter_P; //P value of current loop
	float Current_Filter_I; //I value of current loop
	float Velocity_Filter_P; //P value of velocity loop
	float Velocity_Filter_I; //I value of velocity loop
	float Position_Filter_P; //P value of position loop
	float Position_Filter_I; //I value of position loop
	//float Position_Filter_D; //D value of position loop
	float PP_Max_Velocity; //Maximum velocity of position trapezoid
	float PP_Max_Acceleration; //Maximum acceleration of position trapezoid
	float PP_Max_Deceleration; //Maximum value of position trapezoidal deceleration
	float PV_Max_Velocity; //Maximum velocity of velocity trapezoid
	float PV_Max_Acceleration; //Maximum acceleration of velocity trapezoid
	float PV_Max_Deceleration; //Maximum speed trapezoidal deceleration
	//float Current_Filter_Limit_L; //lower limit of current loop output
	//float Current_Filter_Limit_H; //current loop output upper limit
	float Velocity_Filter_Limit_L; //Lower limit of velocity loop output
	float Velocity_Filter_Limit_H; //Speed ​​loop output upper limit
	float Position_Filter_Limit_L; //Lower limit of position loop output
	float Position_Filter_Limit_H; //Position loop output upper limit
	float Position_Limit_H; //The upper limit of the position of the actuator
	float Position_Limit_L; //The lower limit of the position of the actuator
	float Current_Limit; //Current input limit
	float Velocity_Limit; //Speed ​​input limit
	float Homing_Value; //Homing value of actuator
	float Position_Offset; //position offset of actuator
	float Homing_Current_Limit_L; //Auto zero current lower limit
	float Homing_Current_Limit_H; //Auto zero current upper limit
	float Blocked_Energy; //Blocked rotor lock energy
	
}SCA_Handler_t;

enum SCA_Error //SCA communication error type enumeration
{
	SCA_NoError = 0, //No error
	SCA_OverTime, //Communication waiting timeout
	SCA_SendError, //Failed to send data
	SCA_OperationFailed, //The operation failed
	SCA_UnknownID, //The actuator handle of the ID was not found
};

/* Data receiving interface, called when a new CAN data packet comes in
  CanRxMsg is the receiving type structure of CAN data packet.
  Define the CanRxMsg structure type according to the platform, here STM32 is used by default
  The receiving structure in the standard library function */
void canDispatch(CanRxMsg* RxMsg);

/* The following functions are called by the API layer */

/* Read command interface */
uint8_t SCA_Read(SCA_Handler_t* pSCA, uint8_t cmd);

/* Five types of write commands */
uint8_t SCA_Write_1(SCA_Handler_t* pSCA, uint8_t cmd, uint8_t TxData);
uint8_t SCA_Write_2(SCA_Handler_t* pSCA, uint8_t cmd, float TxData);
uint8_t SCA_Write_3(SCA_Handler_t* pSCA, uint8_t cmd, float TxData);
uint8_t SCA_Write_4(SCA_Handler_t* pSCA, uint8_t cmd);
uint8_t SCA_Write_5(SCA_Handler_t* pSCA, uint8_t cmd, uint8_t TxData);

#endif
