/**
  ************************************************** ****************************
  * @File: SCA_APP.c
  * @Author: INNFOS Software Team
  * @版本: V1.5.1
  * @日期: 2019.09.10
  * @Abstract: SCA test program
  ************************************************** ****************************/
/* Update log ---------------------------------------------- ----------------------*/
//V1.1.0 2019.08.05 The test program is modified to the latest API interface
//V1.5.0 2019.08.20 The test program is modified to the latest API interface, and the initialization method is changed
//V1.5.1 2019.09.10 add polling function

/* Includes ----------------------------------------------- -----------------------*/
#include "bsp.h"
#include "SCA_APP.h"
#include "SCA_API.h"

/* Variable defines ---------------------------------------------- ----------------*/
SCA_Handler_t* pSCA_ID1 = NULL; //Read and write pointers, which can be used to obtain actuator parameters or call FAST functions
SCA_Handler_t* pSCA_ID2 = NULL;

/* CAN port information definition, used to bind SCA handle to realize multi-port control. It is defined according to the actual number during migration, and 2 are used by default */
CAN_Handler_t CAN_Port1,CAN_Port2;

/* Funcation defines -------------------------------------------------------------*/

/**
  * @Function Find the existing SCA on the CAN bus and print the ID found
  * @Parameter None
  * @回回 None
  * @Note Each actuator has its own ID, if you don’t know it for the first time
  * The corresponding ID can be found by this function. This function needs to open SCA_DEBUGER
  */
void SCA_Lookup()
{
	/* Initialize CAN port parameters */
	CAN_Port1.CanPort = 1; //Mark the port number
	CAN_Port1.Retry = 2; //Number of failed retransmissions
	CAN_Port1.Send = CAN1_Send_Msg; //CAN1 port send function
	
	CAN_Port2.CanPort = 2;
	CAN_Port2.Retry = 2;
	CAN_Port2.Send = CAN2_Send_Msg; //CAN2 port send function
	
	/* Call the function to find the ID that exists on the corresponding bus */
	lookupActuators(&CAN_Port1); //Poll the CAN1 bus
	lookupActuators(&CAN_Port2); //Poll the CAN2 bus
}

/**
  * @Function Controller initialization
  * @Parameter None
  * @回回 None
  */
void SCA_Init()
{
	/* Initialize CAN port parameters */
	CAN_Port1.CanPort = 1; //Mark the port number
	CAN_Port1.Retry = 2; //Number of failed retransmissions
	CAN_Port1.Send = CAN1_Send_Msg; //CAN1 port send function
	
	CAN_Port2.CanPort = 2;
	CAN_Port2.Retry = 2;
	CAN_Port2.Send = CAN2_Send_Msg; //CAN2 port send function
	
	/* Load actuator ID and CAN port number used */
	setupActuators( 1, &CAN_Port1); //ID1 is bound to CAN1
	setupActuators( 2, &CAN_Port2); //ID2 is bound to CAN2
	
	/* Get the parameter handle of ID1 and 2 */
	pSCA_ID1 = getInstance(1);
	pSCA_ID2 = getInstance(2);
	
	/* Start all actuators */
	enableAllActuators();
}

/**
  * @Function reset position
  * @Parameter None
  * @回回 None
  */
void SCA_Homing()
{
	/* Exit without booting */
	if(pSCA_ID1->Power_State == Actr_Disable) return;
	if(pSCA_ID2->Power_State == Actr_Disable) return;
	
	/* Switch actuator operation mode to trapezoidal position mode */
	activateActuatorMode(0x01,SCA_Profile_Position_Mode,Block);
	activateActuatorMode(0x02,SCA_Profile_Position_Mode,Block);
	
	/* Return to zero No. 1 actuator */
	setPosition(0x01,0);
	
	/* Waiting for zero return success */
	do
	{
		getPosition(0x01,Unblock);
		delay_ms(100);
	}
	while((pSCA_ID1->Position_Real> 0.1f)||(pSCA_ID1->Position_Real <-0.1f));
	
	/* Return to zero No. 2 actuator*/
	setPosition(0x02,0);
	
	/* Waiting for zero return success */
	do
	{
		getPosition(0x02,Unblock);
		delay_ms(100);
	}
	while((pSCA_ID2->Position_Real> 0.1f)||(pSCA_ID2->Position_Real <-0.1f));
}

/**
  * @Function Forward and reverse switch twice
  * @Parameter None
  * @回回 None
  */
void SCA_Exp1()
{
	/* Exit without booting */
	if(pSCA_ID1->Power_State == Actr_Disable) return;
	if(pSCA_ID2->Power_State == Actr_Disable) return;
	
	/* Reset to zero */
	SCA_Homing();
	
	/* Turn on forward and reverse */
	setPosition(0x01,2); //Ordinary function calls actuator 0x01 with ID
	setPositionFast(pSCA_ID2,2); //FAST type function calls actuator 0x02 in pointer form
	delay_ms(1000);
	
	setPosition(0x01,0);
	setPositionFast(pSCA_ID2,0);
	delay_ms(1000);
	
	setPosition(0x01,2);
	setPositionFast(pSCA_ID2,2);
	delay_ms(1000);
	
	setPosition(0x01,0);
	setPositionFast(pSCA_ID2,0);
	delay_ms(1000);
}

/**
  * @Function High and low speed switch
  * @Parameter None
  * @回回 None
  */
void SCA_Exp2()
{
	/* Exit without booting */
	if(pSCA_ID1->Power_State == Actr_Disable) return;
	if(pSCA_ID2->Power_State == Actr_Disable) return;
	
	/* Switch actuator operation mode to trapezoidal speed mode */
	activateActuatorMode(0x01,SCA_Profile_Velocity_Mode,Block);
	activateActuatorMode(0x02,SCA_Profile_Velocity_Mode,Block);
	
	/* Turn on forward and reverse */
	setVelocity(0x01,300);
	setVelocityFast(pSCA_ID2,300);
	delay_ms(1000);
	
	setVelocity(0x01,600);
	setVelocityFast(pSCA_ID2,600);
	delay_ms(1000);
	
	setVelocity(0x01,300);
	setVelocityFast(pSCA_ID2,300);
	delay_ms(1000);
	
	setVelocity(0x01,600);
	setVelocityFast(pSCA_ID2,600);
	delay_ms(1000);
	
	/* stop */
	setVelocity(0x01,0);
	setVelocityFast(pSCA_ID2,0);
}
